package com.example.designerdiary;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class Cart extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DatabaseReference mDatabase;
    private FirebaseRecyclerAdapter<Post2, postViewHolder> mAdapter;
    private FirebaseAuth firebaseAuth;

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        firebaseAuth=FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("buyer");
        recyclerView = (RecyclerView) findViewById(R.id.recycler2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    protected void onStart() {
        super.onStart();

        recyclerView.setVisibility(View.GONE);
        FirebaseRecyclerOptions<Post2> options = new FirebaseRecyclerOptions.Builder<Post2>()
                .setQuery(mDatabase, Post2.class)
                .build();
        mAdapter = new FirebaseRecyclerAdapter<Post2, postViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final postViewHolder holder, int position, @NonNull Post2 model) {
                holder.Name.setText("Name : "+ model.getName());
                holder.Amount.setText("Amount : Rs. " + model.getAmount());
                holder.Phone.setText("Buyer Phone no. : " + model.getPhone());
                Picasso.get().load(model.getImageURL()).into(holder.imageView);
            }
            @Override
            @NonNull
            public postViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.postb, viewGroup, false);
                return new postViewHolder(view);
            }
        };
        mAdapter.startListening();
        recyclerView.setAdapter(mAdapter);
        recyclerView.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.stopListening();
    }
    public static class postViewHolder extends RecyclerView.ViewHolder {

        TextView Amount;
        TextView Name;
        TextView Phone;
        ImageView imageView;
        public postViewHolder(View itemView) {
            super(itemView);
            Name = (TextView) itemView.findViewById(R.id.bName);
            Amount = (TextView)itemView.findViewById(R.id.bBid);
            Phone= (TextView)itemView.findViewById(R.id.bPhone);
            imageView = (ImageView)itemView.findViewById(R.id.image_view);
        }
    }
}


