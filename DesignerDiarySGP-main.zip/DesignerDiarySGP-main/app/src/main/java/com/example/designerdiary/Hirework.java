package com.example.designerdiary;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class Hirework extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DatabaseReference mDatabase;
    private Toolbar toolbar;
    private FirebaseRecyclerAdapter<Post3, postViewHolder> mAdapter;
    private FirebaseRecyclerAdapter<Post3, postViewHolder> kAdapter;
    private FirebaseRecyclerAdapter<Post3, postViewHolder> nAdapter;
    private FirebaseAuth firebaseAuth;
    DatabaseReference likereference;
    Boolean testclick=false;

    private Button sort;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hirework);
        toolbar = findViewById(R.id.toolbar30);
        firebaseAuth=FirebaseAuth.getInstance();
        sort =findViewById(R.id.sort);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");
        FirebaseUser user = firebaseAuth.getCurrentUser();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("work");
        likereference=FirebaseDatabase.getInstance().getReference("likes");
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view0);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        sort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseRecyclerOptions<Post3> option2 =
                        new FirebaseRecyclerOptions.Builder<Post3>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("work").orderByChild("likes").startAt(0),Post3.class)
                                .build();
                nAdapter = new FirebaseRecyclerAdapter<Post3, postViewHolder>(option2) {
                    @Override
                    protected void onBindViewHolder(@NonNull final postViewHolder holder, int position, @NonNull Post3 model) {
                        holder.name.setText(model.getWorkName());
                        holder.qua.setText("Qualification : " + model.getQua());
                        holder.skills.setText("Skills : " + model.getSkills());
                        holder.exp.setText("Experience : " + model.getExp());
                        holder.email.setText("Email : " + model.getEmail());
                        holder.phone.setText("Phone : " + model.getPhone());
                        holder.city.setText("City : " + model.getCity());
                        holder.like.setText("like : " + model.getLikes().toString());

                        Picasso.get().load(model.getImageUrl()).into(holder.imageView);
                        FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                        final String userid=firebaseUser.getUid();
                        final String postkey=getRef(position).getKey();
                        holder.getlikebuttonstatus(postkey,userid);
                        holder.like_btn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                testclick=true;

                                likereference.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if(testclick==true)
                                        {
                                            if(snapshot.child(postkey).hasChild(userid))
                                            {
                                                likereference.child(postkey).child(userid).removeValue();
                                                testclick=false;
                                            }
                                            else
                                            {
                                                likereference.child(postkey).child(userid).setValue(true);
                                                testclick=false;
                                            }
                                        }
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                    }
                                });
                            }
                        });
                        holder.connect.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent intent = new Intent(Intent.ACTION_DIAL);
                                intent.setData(Uri.parse("tel:"+model.getPhone()));
                                startActivity(intent);
                            }
                        });
                    }
                    @Override
                    @NonNull
                    public postViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                        View view = LayoutInflater.from(viewGroup.getContext())
                                .inflate(R.layout.postc, viewGroup, false);
                        return new postViewHolder(view);
                    }
                };
                nAdapter.startListening();
                recyclerView.setAdapter(nAdapter);
                recyclerView.setVisibility(View.VISIBLE);
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.searchmenu,menu);
        MenuItem item=menu.findItem(R.id.search);
        SearchView searchView=(SearchView)item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                processsearch(s);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                processsearch(s);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }
    protected void onStart() {
        super.onStart();

        recyclerView.setVisibility(View.GONE);
        FirebaseRecyclerOptions<Post3> options = new FirebaseRecyclerOptions.Builder<Post3>()
                .setQuery(mDatabase, Post3.class)
                .build();
        mAdapter = new FirebaseRecyclerAdapter<Post3, postViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final postViewHolder holder, int position, @NonNull Post3 model) {
                holder.name.setText(model.getWorkName());
                holder.qua.setText("Qualification : " + model.getQua());
                holder.skills.setText("Skills : " + model.getSkills());
                holder.exp.setText("Experience : " + model.getExp());
                holder.email.setText("Email : " + model.getEmail());
                holder.phone.setText("Phone : " + model.getPhone());
                holder.city.setText("City : " + model.getCity());
                holder.like.setText("like : " + model.getLikes().toString());
                Picasso.get().load(model.getImageUrl()).into(holder.imageView);
                FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                final String userid=firebaseUser.getUid();
                final String postkey=getRef(position).getKey();
                holder.getlikebuttonstatus(postkey,userid);
                holder.like_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        testclick=true;
                        likereference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(testclick==true)
                                {
                                    if(snapshot.child(postkey).hasChild(userid))
                                    {
                                        likereference.child(postkey).child(userid).removeValue();
                                        testclick=false;
                                    }
                                    else
                                    {
                                        likereference.child(postkey).child(userid).setValue(true);
                                        testclick=false;
                                    }
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }
                });
                holder.connect.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:"+model.getPhone()));
                        startActivity(intent);
                    }
                });

            }

            @Override
            @NonNull
            public postViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.postc, viewGroup, false);
                return new postViewHolder(view);
            }
        };
        mAdapter.startListening();
        recyclerView.setAdapter(mAdapter);
        recyclerView.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.stopListening();
    }
    private void processsearch(String s)
    {
        FirebaseRecyclerOptions<Post3> option0 =
                new FirebaseRecyclerOptions.Builder<Post3>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("work").orderByChild("skills").startAt(s).endAt(s+"\uf8ff"),Post3.class)
                        .build();
        kAdapter = new FirebaseRecyclerAdapter<Post3, postViewHolder>(option0) {
            @Override
            protected void onBindViewHolder(@NonNull final postViewHolder holder, int position, @NonNull Post3 model) {
                holder.name.setText(model.getWorkName());
                holder.qua.setText("Qualification : " + model.getQua());
                holder.skills.setText("Skills : " + model.getSkills());
                holder.exp.setText("Experience : " + model.getExp());
                holder.email.setText("Email : " + model.getEmail());
                holder.phone.setText("Phone : " + model.getPhone());
                holder.city.setText("City : " + model.getCity());
                holder.like.setText("like : " + model.getLikes().toString());
                Picasso.get().load(model.getImageUrl()).into(holder.imageView);
                FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                final String userid=firebaseUser.getUid();
                final String postkey=getRef(position).getKey();
                holder.getlikebuttonstatus(postkey,userid);
                holder.like_btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        testclick=true;

                        likereference.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(testclick==true)
                                {
                                    if(snapshot.child(postkey).hasChild(userid))
                                    {
                                        likereference.child(postkey).child(userid).removeValue();
                                        testclick=false;
                                    }
                                    else
                                    {
                                        likereference.child(postkey).child(userid).setValue(true);
                                        testclick=false;
                                    }
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }
                });
                holder.connect.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Intent.ACTION_DIAL);
                        intent.setData(Uri.parse("tel:"+model.getPhone()));
                        startActivity(intent);
                    }
                });
            }
            @Override
            @NonNull
            public postViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.postc, viewGroup, false);
                return new postViewHolder(view);
            }
        };
        kAdapter.startListening();
        recyclerView.setAdapter(kAdapter);
        recyclerView.setVisibility(View.VISIBLE);
    }

    public static class postViewHolder extends RecyclerView.ViewHolder {

        ImageView like_btn;
        TextView like_text;
        DatabaseReference likereference;
        TextView phone,name,qua,exp,skills,email,city,like;
        ImageView imageView;
        Button connect;


        public void getlikebuttonstatus(final String postkey, final String userid)
        {
            likereference= FirebaseDatabase.getInstance().getReference("likes");//for get the database ref. named "likes"
            likereference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.child(postkey).hasChild(userid))//if block to check if post is already liked or not
                    {
                        int likecount=(int)snapshot.child(postkey).getChildrenCount();//get the no. of likes from firebase database
                        like_text.setText(likecount+" likes");//set the no. of likes on text of post
                        FirebaseDatabase.getInstance().getReference().child("work").child(postkey).child("likes").setValue(likecount);
                        //change the no. of likes in database named work and likes both at once
                        like_btn.setImageResource(R.drawable.ic_baseline_favorite_24);//to change the pic of like on click of like button
                    }
                    else// if not already liked
                    {
                        int likecount=(int)snapshot.child(postkey).getChildrenCount();//get the no. of likes from firebase database
                        like_text.setText(likecount+" likes");//set the no. of likes on text of post
                        FirebaseDatabase.getInstance().getReference().child("work").child(postkey).child("likes").setValue(likecount);
                        //change the no. of likes in database named work and likes both at once
                        like_btn.setImageResource(R.drawable.ic_baseline_favorite_border_24);
                        //to change the pic of like on click of like button
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

        public postViewHolder(View itemView) {
            super(itemView);
            name= (TextView)itemView.findViewById(R.id.wname);
            qua= (TextView)itemView.findViewById(R.id.wqua);
            skills= (TextView)itemView.findViewById(R.id.wskills);
            exp= (TextView)itemView.findViewById(R.id.wexp);
            connect=(Button)itemView.findViewById(R.id.connect);
            email= (TextView)itemView.findViewById(R.id.wemail);
            phone= (TextView)itemView.findViewById(R.id.wphone);
            like_btn=(ImageView)itemView.findViewById(R.id.like_btn);
            like_text=(TextView)itemView.findViewById(R.id.like_text);
            city= (TextView)itemView.findViewById(R.id.wcity);
            imageView = (ImageView)itemView.findViewById(R.id.wimage);
            like =  (TextView)itemView.findViewById(R.id.wlike);
        }
    }

}

