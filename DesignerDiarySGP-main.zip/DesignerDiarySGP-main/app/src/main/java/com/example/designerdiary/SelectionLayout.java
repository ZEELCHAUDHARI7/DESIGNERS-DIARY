package com.example.designerdiary;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import androidx.appcompat.app.AppCompatActivity;

public class SelectionLayout extends AppCompatActivity  {

    private RadioButton r1;
    private RadioButton r2;
    private Button start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection_layout);

        r1 = (RadioButton) findViewById(R.id.work);
        r2 = (RadioButton) findViewById(R.id.hire);
        start = (Button) findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r1.isChecked()) {
                    startActivity(new Intent(SelectionLayout.this, Work.class));
                } else if (r2.isChecked()) {
                    startActivity(new Intent(SelectionLayout.this, Hire.class));
                }
            }
        });
    }
}