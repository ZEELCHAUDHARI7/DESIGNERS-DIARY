package com.example.designerdiary;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class Hire extends AppCompatActivity implements View.OnClickListener{
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hire);
        findViewById(R.id.W).setOnClickListener(this);
        findViewById(R.id.P).setOnClickListener(this);

    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.W:
                startActivity(new Intent(this,Hirework.class));
                break;
            case R.id.P:

                startActivity(new Intent(this, Hireitem.class));
                break;
        }
    }
}
