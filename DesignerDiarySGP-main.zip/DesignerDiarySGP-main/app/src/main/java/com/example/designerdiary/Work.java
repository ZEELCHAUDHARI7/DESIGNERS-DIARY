package com.example.designerdiary;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class Work extends AppCompatActivity implements View.OnClickListener {
    private Toolbar toolbar;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ActionBarDrawerToggle toggle;
    private DatabaseReference databaseReference;
    private TextView profileSurnameTextView,profileNameTextView,n,s;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase firebaseDatabase;
    private ImageView profilePicImageView,i;
    private FirebaseStorage firebaseStorage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work);

            toolbar = findViewById(R.id.toolbar);
            navigationView = findViewById(R.id.navigationView);
            drawerLayout = findViewById(R.id.drawer);
            setSupportActionBar(toolbar);
            getSupportActionBar().setTitle("Work");
            toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
            drawerLayout.addDrawerListener(toggle);
            toggle.syncState();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        View headerView = navigationView.getHeaderView(0);
        profilePicImageView = headerView.findViewById(R.id.image);
        profileNameTextView = headerView.findViewById(R.id.name);
        profileSurnameTextView = headerView.findViewById(R.id.Surname);
        i= findViewById(R.id.image2);
        n = findViewById(R.id.n);
        s = findViewById(R.id.s);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseStorage = FirebaseStorage.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference().child("profile").child(firebaseAuth.getUid());
        StorageReference storageReference = firebaseStorage.getReference();
        // Get the image stored on Firebase via "User id/Images/Profile Pic.jpg".
        storageReference.child(firebaseAuth.getUid()).child("Images").child("Profile Pic").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {

                Picasso.get().load(uri).fit().centerInside().into(profilePicImageView);
                Picasso.get().load(uri).fit().centerInside().into(i);
            }
        });
        if (firebaseAuth.getCurrentUser() == null){
            finish();
            startActivity(new Intent(getApplicationContext(),Work.class));
        }
        final FirebaseUser user=firebaseAuth.getCurrentUser();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Userinformation userProfile = dataSnapshot.getValue(Userinformation.class);
                assert userProfile != null;
                profileNameTextView.setText(userProfile.getUserName());
                profileSurnameTextView.setText(userProfile.getUserSurname());
                n.setText(userProfile.getUserName());
                s.setText(userProfile.getUserSurname());


            }
            @Override
            public void onCancelled( DatabaseError databaseError) {
                Toast.makeText(Work.this, "database error", Toast.LENGTH_SHORT).show();
            }
        });

            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    drawerLayout.closeDrawer(GravityCompat.START);
                    switch (item.getItemId()){
                        case R.id.work:// case for button named work
                            Intent k= new Intent(Work.this, workprofile.class);
                            startActivity(k);// k is activity intent for continue with work profile
                            break;

                        case R.id.item:
                            Intent k2= new Intent(Work.this, additem.class);
                            startActivity(k2);
                            break;

                        case R.id.cart:
                            Intent k3= new Intent(Work.this, Cart.class);
                            startActivity(k3);
                        break;

                        case R.id.edit:
                            Intent k4= new Intent(Work.this, profile.class);
                            startActivity(k4);
                            break;

                            case R.id.logoutuser:
                                FirebaseAuth.getInstance().signOut();
                                Intent inent = new Intent(Work.this, MainActivity.class);
                                startActivity(inent);
                        break;

                    }
                    return true;
                }
            });
        }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button21:
                Intent k10= new Intent(Work.this, profile.class);
                startActivity(k10);
                break;

        }
    }
}
