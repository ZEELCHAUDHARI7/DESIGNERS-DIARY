package com.example.designerdiary;

public class Post1 {
    private String itemName;
    private String description;
    private String baseBid;
    private String Email;
    private String imageUrl;
    private String phone;
    private String city;
    private String ID;


    public Post1() {}
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }


    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String startTime) {
        this.Email = startTime;
    }



    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getBaseBid() {
        return baseBid;
    }

    public void setBaseBid(String baseBid) {
        this.baseBid = baseBid;
    }

    public String getID() {
        return ID;
    }
    public void setID(String ID) {
        this.ID= ID;
    }
}
