package com.example.designerdiary;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class Hireitem extends AppCompatActivity  {


    private RecyclerView recyclerView;

    private DatabaseReference mDatabase;
    private DatabaseReference m;
    private FirebaseRecyclerAdapter<Post1, PostViewHolder> mAdapter;

    private ProgressBar progressBar;
    private FirebaseAuth firebaseAuth;
    DatabaseReference likereference1;
    Boolean testclick1=false;
    private Button btnEnterBid;
    private Dialog MyDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_hireitem);
        mDatabase = FirebaseDatabase.getInstance().getReference().child("item");
        m = FirebaseDatabase.getInstance().getReference().child("buyer");
        likereference1=FirebaseDatabase.getInstance().getReference("like");
        recyclerView = findViewById(R.id.recycler_view);
        progressBar = findViewById(R.id.bar);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void AletDialog(final PostViewHolder holder){
        MyDialog = new Dialog(Hireitem.this);
        MyDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        MyDialog.setContentView(R.layout.activity_bid);
        MyDialog.setTitle("CART");
        btnEnterBid = MyDialog.findViewById(R.id.btnEnterBidDialog);
        final EditText editEnterBid = MyDialog.findViewById(R.id.editEnterBid);
        final EditText editEnterPhone = MyDialog.findViewById(R.id.editEnterPhone);
        final EditText editEnterName = MyDialog.findViewById(R.id.editEnterName);
        btnEnterBid.setEnabled(true);
        btnEnterBid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                holder.Name = editEnterName.getText().toString().trim();

                holder.Phone = editEnterPhone.getText().toString().trim();
                holder.Amount = editEnterBid.getText().toString().trim();
                String bidAmount =  holder.Amount;
                String bidPhone =  holder.Phone;
                String bidName =  holder.Name;
                String ID= (String) holder.ID.getText();
                String i1=holder.img;
                DatabaseReference Bu = m.child(ID);
                Bu.child("Amount").setValue(bidAmount);
                Bu.child("Phone").setValue(bidPhone);
                Bu.child("Name").setValue(bidName);
                Bu.child("ID").setValue(ID);
                Bu.child("ImageURL").setValue(i1);
                holder.didBid = true;

                Toast.makeText(getApplicationContext(), "Your Request for is successful", Toast.LENGTH_SHORT).show();
                MyDialog.dismiss();
            }
        });

        MyDialog.show();
    }

    @Override
    protected void onStart() {
        super.onStart();

        progressBar.setVisibility(View.VISIBLE);
        progressBar.bringToFront();
        recyclerView.setVisibility(View.GONE);
        FirebaseRecyclerOptions<Post1> options = new FirebaseRecyclerOptions.Builder<Post1>()
                .setQuery(mDatabase, Post1.class)
                .build();

        mAdapter = new FirebaseRecyclerAdapter<Post1, PostViewHolder>(options) {

            protected void onBindViewHolder(@NonNull final PostViewHolder holder, int position, @NonNull Post1 model) {
                holder.itemName.setText(model.getItemName());
                holder.itemDesc.setText(model.getDescription());
                holder.baseBid.setText("Price : Rs. " + model.getBaseBid());
                holder.email.setText("Email : " + model.getEmail());
                holder.phone.setText("Phone no. : " + model.getPhone());
                holder.city.setText("Location : " + model.getCity());
                holder.ID.setText(model.getID());
                holder.img=model.getImageUrl();
                Picasso.get().load(model.getImageUrl()).into(holder.imageView);
                FirebaseUser firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
                final String userid=firebaseUser.getUid();
                final String postkey=getRef(position).getKey();
                holder.getlikebuttonstatus(postkey,userid);
                holder.like_btn1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        testclick1=true;
                        likereference1.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if(testclick1==true)
                                {
                                    if(snapshot.child(postkey).hasChild(userid))
                                    {
                                        likereference1.child(postkey).child(userid).removeValue();
                                        testclick1=false;
                                    }
                                    else
                                    {
                                        likereference1.child(postkey).child(userid).setValue(true);
                                        testclick1=false;
                                    }
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                            }
                        });
                    }
                });
                holder.bidBn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(!holder.didBid)
                            AletDialog(holder);
                        else
                            Toast.makeText(getApplicationContext(), "Your Request is successful added", Toast.LENGTH_LONG).show();
                    }
                });
            }

            @NonNull
            public PostViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view = LayoutInflater.from(viewGroup.getContext())
                        .inflate(R.layout.model_post, viewGroup, false);

                return new PostViewHolder(view);
            }
        };

        mAdapter.startListening();
        recyclerView.setAdapter(mAdapter);
        progressBar.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        mAdapter.stopListening();
    }

    public static class PostViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        TextView itemDesc;
        TextView baseBid;
        TextView email;
        TextView ID;
        TextView phone;
        TextView city;
        ImageView imageView;
        Button bidBn;
        boolean didBid;
        String Amount;
        String img;
        String Phone;
        String Name;
        ImageView like_btn1;
        TextView like_text1;
        DatabaseReference likereference;

        public void getlikebuttonstatus(final String postkey, final String userid)
        {
            likereference= FirebaseDatabase.getInstance().getReference("like");
            likereference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.child(postkey).hasChild(userid))
                    {
                        int likecount1=(int)snapshot.child(postkey).getChildrenCount();
                        like_text1.setText(likecount1+" likes");
                        FirebaseDatabase.getInstance().getReference().child("item").child(postkey).child("like").setValue(likecount1);
                        like_btn1.setImageResource(R.drawable.ic_baseline_favorite_24);
                    }
                    else
                    {
                        int likecount1=(int)snapshot.child(postkey).getChildrenCount();
                        like_text1.setText(likecount1+" likes");
                        FirebaseDatabase.getInstance().getReference().child("item").child(postkey).child("like").setValue(likecount1);
                        like_btn1.setImageResource(R.drawable.ic_baseline_favorite_border_24);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        public PostViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.item_name);
            itemDesc = itemView.findViewById(R.id.description);
            baseBid = itemView.findViewById(R.id.base_bid);
            email = itemView.findViewById(R.id.start_time);
            ID= itemView.findViewById(R.id.ID);
            like_btn1=(ImageView)itemView.findViewById(R.id.like_btn1);
            like_text1=(TextView)itemView.findViewById(R.id.like_text1);
            phone = itemView.findViewById(R.id.phone1);
            city = itemView.findViewById(R.id.city1);
            imageView = itemView.findViewById(R.id.image_vie);
            bidBn = itemView.findViewById(R.id.btnEnterAmount);
            didBid = false;

            Amount = "";
            Phone = "";
            Name = "";
            img="";
        }
    }
}


