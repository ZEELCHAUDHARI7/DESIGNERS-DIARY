package com.example.designerdiary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

public class Register extends AppCompatActivity implements View.OnClickListener{

      EditText username,password,name,pass;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
            username = (EditText) findViewById(R.id.username);
            password = (EditText) findViewById(R.id.password1);
            name = (EditText) findViewById(R.id.name1);
            pass = (EditText) findViewById(R.id.pass);
            mAuth = FirebaseAuth.getInstance();
            findViewById(R.id.login).setOnClickListener(this);
            findViewById(R.id.login1).setOnClickListener(this);
        }

        private void registeruser() {

            String email = username.getText().toString().trim();
            String pd = password.getText().toString().trim();
            String pd1 = pass.getText().toString().trim();
            int c=0;
            if (email.isEmpty()) {
                username.setError("Email is required");
                username.requestFocus();
                return;
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                username.setError("please enter a valid email");
                username.requestFocus();
                return;
            }
            if (pd.isEmpty()) {
                password.setError("password is required");
                password.requestFocus();
                return;
            }
            if (pd.length() < 6) {
                password.setError("minimum length of password should be 6");
                password.requestFocus();
                return;
            }
            if(!(pd.equals(pd1))) {
                password.setError("please enter password same as conform password");
                password.requestFocus();
                return;
            }
            mAuth.createUserWithEmailAndPassword(email, pd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(getApplicationContext(), "User Registered SuccessFull", Toast.LENGTH_SHORT).show();
                        Intent k = new Intent(Register.this, Login.class);
                        startActivity(k);
                    } else
                            {
                        if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                            Toast.makeText(getApplicationContext(), "you are already registered", Toast.LENGTH_SHORT).show();
                            Intent k = new Intent(Register.this, Login.class);
                            startActivity(k);
                        } else
                            {
                            Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }

        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.login:
                    registeruser();
                    break;

                case R.id.login1:
                    startActivity(new Intent(this, Login.class));
                    break;
            }
        }

}